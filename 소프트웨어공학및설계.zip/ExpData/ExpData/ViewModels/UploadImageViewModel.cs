﻿using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;

namespace DataViewExp.ViewModels
{
    public class UploadImageViewModel
    {
        [Display(Name = "File upload")]
        public IFormFile experimentPicture { get; set; }
    }
}
