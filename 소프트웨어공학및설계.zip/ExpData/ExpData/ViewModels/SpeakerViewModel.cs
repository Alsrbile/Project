﻿using System;
using System.ComponentModel.DataAnnotations;

namespace DataViewExp.ViewModels
{
    public class experimentViewModel : EditImageViewModel
    {
        [Required]
        [Display(Name = "experiment Name")]
        public string experimentName { get; set; }

        [Required]
        public string Specifications { get; set; }

        [Required]
        public int Identification { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Date")]
        public DateTime ExperimentDate { get; set; }

        [Required]
        [DataType(DataType.Time)]
        [Display(Name = "Time")]
        public DateTime ExperimentTime { get; set; }

        [Required]
        public string Venue { get; set; }
    }
}
