﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DataViewExp.Models
{
    public static class FileLocation
    {
        public const string FileUploadFolder = "Uploads";
        public const string RetriveFileFromFolder = "~/Uploads/";
        public const string DeleteFileFromFolder = "wwwroot\\Uploads\\";
    }
}
