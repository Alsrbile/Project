﻿using DataViewExp.Models;
using Microsoft.EntityFrameworkCore;

namespace DataViewExp.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) :
            base(options)
        {

        }
        public DbSet<experiment> experiments { get; set; }

    }
}
