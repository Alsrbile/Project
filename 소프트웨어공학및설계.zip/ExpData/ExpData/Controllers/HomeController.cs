﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Linq;
using DataViewExp.Data;
using DataViewExp.Models;
using System.Collections.Generic;
using System.Data.OleDb;
using System;


namespace DataViewExp.Controllers
{
    public class HomeController : Controller
    {
        private static List<CData> listDatas = new List<CData>();

        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext db;
        public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
        {
            _logger = logger;
            db = context;
        }

        public IActionResult Index()
        {
            var experiment = db.experiments.ToList();
            

            return View(experiment);

        }
        public IActionResult IIndex()
        {
            //  CPerson aPerson=new() { Name = "Tom", Age = 100 };
            //  return View(aPerson);
            return View(listDatas);
        }

        

    }

  
}


