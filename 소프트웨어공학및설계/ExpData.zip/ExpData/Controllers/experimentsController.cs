﻿using DataViewExp.Data;
using DataViewExp.Models;
using DataViewExp.ViewModels;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;




namespace DataViewExp.Controllers
{
    public class experimentsController : Controller
    {
        
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _environment;
        public experimentsController(ApplicationDbContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        public async Task<IActionResult> Index()
        {
            return View(await _context.experiments.ToListAsync());
        }

        public async Task<IActionResult> Details(int? id)
        {
            try
            {
                if (id == null)
                {
                    return NotFound();
                }

                var experiment = await _context.experiments
                    .FirstOrDefaultAsync(m => m.Id == id);

                var experimentViewModel = new experimentViewModel()
                {
                    Id = experiment.Id,
                    experimentName = experiment.experimentName,
                    Specifications = experiment.Specifications,
                    Identification = experiment.Identification,
                    ExperimentDate = experiment.ExperimentDate,
                    ExperimentTime = experiment.ExperimentTime,
                    Venue = experiment.Venue,
                    ExistingImage = experiment.ProfilePicture
                };

                if (experiment == null)
                {
                    return NotFound();
                }
                return View(experiment);
            }
            catch (Exception)
            {

                throw;
            }
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(experimentViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    string uniqueFileName = ProcessUploadedFile(model);
                    experiment experiment = new()
                    {
                        experimentName = model.experimentName,
                        Specifications = model.Specifications,
                        Identification = model.Identification,
                        ExperimentDate = model.ExperimentDate,
                        ExperimentTime = model.ExperimentTime,
                        Venue = model.Venue,
                        ProfilePicture = uniqueFileName
                    };

                    _context.Add(experiment);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
            }
            catch (Exception)
            {

                throw;
            }
            return View(model);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var experiment = await _context.experiments.FindAsync(id);
            var experimentViewModel = new experimentViewModel()
            {
                Id = experiment.Id,
                experimentName = experiment.experimentName,
                Specifications = experiment.Specifications,
                Identification = experiment.Identification,
                ExperimentDate = experiment.ExperimentDate,
                ExperimentTime = experiment.ExperimentTime,
                Venue = experiment.Venue,
                ExistingImage = experiment.ProfilePicture
            };

            if (experiment == null)
            {
                return NotFound();
            }
            return View(experimentViewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, experimentViewModel model)
        {
            if (ModelState.IsValid)
            {
                var experiment = await _context.experiments.FindAsync(model.Id);
                experiment.experimentName = model.experimentName;
                experiment.Specifications = model.Specifications;
                experiment.Identification = model.Identification;
                experiment.ExperimentDate = model.ExperimentDate;
                experiment.ExperimentTime = model.ExperimentTime;
                experiment.Venue = model.Venue;

                if (model.experimentPicture != null)
                {
                    if (model.ExistingImage != null)
                    {
                        string filePath = Path.Combine(_environment.WebRootPath, "Uploads", model.ExistingImage);
                        System.IO.File.Delete(filePath);
                    }

                    experiment.ProfilePicture = ProcessUploadedFile(model);
                }
                _context.Update(experiment);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var experiment = await _context.experiments
                .FirstOrDefaultAsync(m => m.Id == id);

            var experimentViewModel = new experimentViewModel()
            {
                Id = experiment.Id,
                experimentName = experiment.experimentName,
                Specifications = experiment.Specifications,
                Identification = experiment.Identification,
                ExperimentDate = experiment.ExperimentDate,
                ExperimentTime = experiment.ExperimentTime,
                Venue = experiment.Venue,
                ExistingImage = experiment.ProfilePicture
            };
            if (experiment == null)
            {
                return NotFound();
            }

            return View(experimentViewModel);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var experiment = await _context.experiments.FindAsync(id);
            //string deleteFileFromFolder = "wwwroot\\Uploads\\";
            string deleteFileFromFolder=Path.Combine(_environment.WebRootPath, "Uploads");
            var CurrentImage = Path.Combine(Directory.GetCurrentDirectory(), deleteFileFromFolder,experiment.ProfilePicture);
            _context.experiments.Remove(experiment);
            if (System.IO.File.Exists(CurrentImage))
            {
                System.IO.File.Delete(CurrentImage);
            }
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool experimentExists(int id)
        {
            return _context.experiments.Any(e => e.Id == id);
        }

        private string ProcessUploadedFile(experimentViewModel model)
        {
            string uniqueFileName = null;
            string path = Path.Combine(_environment.WebRootPath, "Uploads");
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            if (model.experimentPicture != null)
            {
                string uploadsFolder = Path.Combine(_environment.WebRootPath, "Uploads");
                uniqueFileName =  model.experimentPicture.FileName;
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    model.experimentPicture.CopyTo(fileStream);
                }
            }

            return uniqueFileName;
        }
    }
}
