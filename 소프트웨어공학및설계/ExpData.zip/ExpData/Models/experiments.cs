﻿using System;
using System.ComponentModel.DataAnnotations;

namespace DataViewExp.Models
{
    public class experiment
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        [Display(Name = "Name")]
        public string experimentName { get; set; }

        [Required]
        [StringLength(100)]
        public string Specifications { get; set; }

        [Required]
        [StringLength(100)]
        public int Identification { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Date")]
        public DateTime ExperimentDate { get; set; }

        [Required]
        [DataType(DataType.Time)]
        [Display(Name = "Time")]
        public DateTime ExperimentTime { get; set; }

        [Required]
        [StringLength(255)]
        public string Venue { get; set; }

        [Required]
        [Display(Name = "Data")]
        public string ProfilePicture { get; set; }

       
    }
}
